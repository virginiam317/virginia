<?php
	define('TABLE_PRE_STORE', DB_PREFIX . 'pre_store');
