<?php
	define('TABLE_DIRECT_DEPOSIT', DB_PREFIX . 'direct_deposit');
