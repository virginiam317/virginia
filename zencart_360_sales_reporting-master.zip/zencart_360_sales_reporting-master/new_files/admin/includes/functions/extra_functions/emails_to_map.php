<?php
  $emails_to_map = array(
                    array('old-email@example.com', 'new-email@newsite.com'),
                    );

