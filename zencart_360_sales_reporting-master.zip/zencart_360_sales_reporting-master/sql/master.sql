ALTER TABLE customers ADD master_account int(11) default 0; 
